export default function infoTypes() {
  // const infoTypes = document.querySelectorAll('.info-types');
  // if (infoTypes === null) return;
  // function selectInfoType(el) {
  //   el.addEventListener('click', (e) => {
  //     e.preventDefault();
  //     const prevActiveItem = el.parentElement.querySelector('.info-types__type--is-active');
  //     if (prevActiveItem !== el) {
  //       prevActiveItem.classList.remove('info-types__type--is-active');
  //       el.classList.add('info-types__type--is-active');
  //     }
  //   });
  // }
  // infoTypes.forEach(el => {
  //   const childNodes = el.childNodes;
  //   childNodes.forEach(el => { selectInfoType(el); });
  // });
}